document.write("mamaamaa");
